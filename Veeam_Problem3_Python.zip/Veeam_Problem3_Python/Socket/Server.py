import socket
import uuid

ip = socket.gethostbyname(socket.gethostname())
port1 = 8000
port2 = 8001
code_identifier = uuid.uuid1()
message_8000 = f'{code_identifier}'.encode('utf-8')
server1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server1.bind((ip, port1))
server2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server2.bind((ip, port2))

server1.listen(50)
server2.listen(50)

dict_element = {}


while True:
    communication_socket1, addr1 = server1.accept()
    print(f'Connected to {addr1}')
    message1 = communication_socket1.recv(1024).decode('utf-8')
    print(f'{message1}')
    communication_socket1.send(message_8000)
    #add element to the dictionary
    dict_element[message_8000.decode()] = message1

    communication_socket2, addr2 = server2.accept()
    print(f'Connected to {addr2}')
    message2 = communication_socket2.recv(1024).decode('utf-8')
    print(f'{message2}')
    # compare the elements from dictionary with the information from the client
    for key, value in dict_element.items():
        if key == message2.split(':')[2] and value == message2.split(':')[1]:
            with open('file.logs', 'a') as f:
                f.write(f'{message2}\n')
        else:
            communication_socket1.send(f'Connection was refused by server'.encode('utf-8'))
            communication_socket2.send(f'Connection was refused by server'.encode('utf-8'))

    code_identifier = uuid.uuid1()
    message_8000 = f'{code_identifier}'.encode('utf-8')

    communication_socket1.close()
    print(f'Communication with {addr1} is ended')
    communication_socket2.close()
    print(f'Communication with {addr2} is ended')




