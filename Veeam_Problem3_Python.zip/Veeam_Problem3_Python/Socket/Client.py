import socket
import uuid

ip = socket.gethostbyname(socket.gethostname())
port1 = 8000
port2 = 8001
unique_identifier = uuid.uuid1()
message_8000 = f'{unique_identifier}'.encode('utf-8')
client_socket1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket1.connect((ip, port1))
client_socket1.send(message_8000)
message_received = client_socket1.recv(1024).decode()
print(message_received)
client_socket2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket2.connect((ip, port2))
client_socket2.send(f'Message to Server :{message_8000.decode()}:{message_received}'.encode())








